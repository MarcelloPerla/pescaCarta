/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pescacarte;

/**
 *
 * @author asunc
 */
public class Persona extends Thread{
    private String  nome;
    private int carta;
    
    public Persona(String nome) {
        this.nome = nome;
    }
    
    @Override
    public void run(){
        System.out.println(nome + " ha iniziato la partita!");
        carta = (int)(10 * Math.random()) + 1;
        System.out.println(nome + " ha pescato il " + carta);
    }

    public String getNome() {
        return nome;
    }

    public int getCarta() {
        return carta;
    }
    
}
