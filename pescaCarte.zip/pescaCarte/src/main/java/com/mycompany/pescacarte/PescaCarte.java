/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pescacarte;

/**
 *
 * @author asunc
 */
public class PescaCarte {

    public static void main(String[] args) throws InterruptedException {
        System.out.println("Partita iniziata");
        
        Persona p1 = new Persona("Xie");
        Persona p2 = new Persona("Pan");
        Persona p3 = new Persona("Lin");
        
        p1.start();
        p2.start(); 
        p3.start(); 
        
        p1.join();
        p2.join(); 
        p3.join(); 
        
        Persona max = p1; 
        
        if(p2.getCarta() > max.getCarta()){
            max = p2;
        }
        
        if(p3.getCarta() > max.getCarta()){
            max = p3;
        }
        
        System.out.println("Il vincitore è " + max.getName());
        System.out.println("partita finita");
    }
}
